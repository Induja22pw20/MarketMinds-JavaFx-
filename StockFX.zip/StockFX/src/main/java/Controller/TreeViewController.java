package Controller;

import Model.Company;
import Model.Handler;
import javafx.fxml.FXML;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

import java.sql.SQLException;
import java.util.ArrayList;

public class TreeViewController {

    @FXML
    private TreeView<String> stockTreeView;

    public void initialize() {
        try {
            loadStockTree();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception (e.g., show an error message)
        }
    }

    private void loadStockTree() throws SQLException {
        // Create root item for stock tree
        TreeItem<String> rootItem = new TreeItem<>("Stocks");

        // Fetch companies from the handler
        ArrayList<Company> companies = Handler.getStockMarket().getCompanies();

        // Create tree items for each company
        for (Company company : companies) {
            TreeItem<String> companyItem = new TreeItem<>(company.getName() + " (" + company.getSymbol() + ")");
            companyItem.getChildren().add(new TreeItem<>("Price: $" + String.format("%.2f", company.getPrice())));
            companyItem.getChildren().add(new TreeItem<>("Volume: " + company.getVolume()));
            companyItem.getChildren().add(new TreeItem<>("Change: " + String.format("%.2f", company.getChange() * 100) + "%"));
            rootItem.getChildren().add(companyItem);
        }

        // Set root item to TreeView
        stockTreeView.setRoot(rootItem);
        stockTreeView.setShowRoot(true);
    }
}
